Launch Section Ferry Booking — iPhone + Android PWA

This package is a Progressive Web App. It is designed to be hosted on HTTPS.
Once hosted:
- iPhone/iPad: open the web address in Safari, Share -> Add to Home Screen.
- Android: open the web address in Chrome, then use "Install app" / "Add to Home screen".
- WhatsApp opens with the booking message prepared; the user still taps Send.

Files:
index.html
manifest.webmanifest
sw.js
icons/
